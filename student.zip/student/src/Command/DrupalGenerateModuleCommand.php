<?php

namespace Drupal\student\Command;

use Symfony\Component\Console\Input\InputInterface;
use Symfony\Component\Console\Output\OutputInterface;
use Drupal\Console\Core\Command\ContainerAwareCommand;

/**
 * Class DrupalGenerateModuleCommand.
 *
 * Drupal\Console\Annotations\DrupalCommand (
 *     extension="student",
 *     extensionType="module"
 * )
 */
class DrupalGenerateModuleCommand extends ContainerAwareCommand {

  /**
   * {@inheritdoc}
   */
  protected function configure() {
    $this
      ->setName('drupal generate:module')
      ->setDescription('generator');
  }

  /**
   * {@inheritdoc}
   */
  protected function execute(InputInterface $input, OutputInterface $output) {
    $this->getIo()->info('It works!');
  }

}
