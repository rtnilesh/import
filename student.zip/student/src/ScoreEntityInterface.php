<?php

namespace Drupal\student;

use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Entity\EntityChangedInterface;
use Drupal\user\EntityOwnerInterface;

/**
 * Provides an interface defining a score entity entity type.
 */
interface ScoreEntityInterface extends ContentEntityInterface, EntityOwnerInterface, EntityChangedInterface {

}
