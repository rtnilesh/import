<?php

namespace Drupal\student\Plugin\Importer;

use Drupal\csv_importer\Plugin\ImporterBase;

/**
 * Class BlockImporter.
 *
 * @Importer(
 *   id = "block_content_importer",
 *   entity_type = "student_type",
 *   label = @Translation("Block content importer")
 * )
 */
class BlockImporter extends ImporterBase {

    
}