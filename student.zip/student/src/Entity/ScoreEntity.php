<?php

namespace Drupal\student\Entity;

use Drupal\Core\Entity\ContentEntityBase;
use Drupal\Core\Entity\EntityChangedTrait;
use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\student\ScoreEntityInterface;
use Drupal\user\EntityOwnerTrait;

/**
 * Defines the score entity entity class.
 *
 * @ContentEntityType(
 *   id = "score_entity",
 *   label = @Translation("score entity"),
 *   label_collection = @Translation("score entities"),
 *   label_singular = @Translation("score entity"),
 *   label_plural = @Translation("score entities"),
 *   label_count = @PluralTranslation(
 *     singular = "@count score entities",
 *     plural = "@count score entities",
 *   ),
 *   handlers = {
 *     "list_builder" = "Drupal\student\ScoreEntityListBuilder",
 *     "views_data" = "Drupal\views\EntityViewsData",
 *     "access" = "Drupal\student\ScoreEntityAccessControlHandler",
 *     "form" = {
 *       "add" = "Drupal\student\Form\ScoreEntityForm",
 *       "edit" = "Drupal\student\Form\ScoreEntityForm",
 *       "delete" = "Drupal\Core\Entity\ContentEntityDeleteForm",
 *     },
 *     "route_provider" = {
 *       "html" = "Drupal\Core\Entity\Routing\AdminHtmlRouteProvider",
 *     }
 *   },
 *   base_table = "score_entity",
 *   admin_permission = "administer score entity",
 *   entity_keys = {
 *     "id" = "id",
 *     "label" = "label",
 *     "uuid" = "uuid",
 *     "owner" = "uid",
 *   },
 *   links = {
 *     "collection" = "/admin/content/score-entity",
 *     "add-form" = "/score-entity/add",
 *     "canonical" = "/score-entity/{score_entity}",
 *     "edit-form" = "/score-entity/{score_entity}/edit",
 *     "delete-form" = "/score-entity/{score_entity}/delete",
 *   },
 *   field_ui_base_route = "entity.score_entity.settings",
 * )
 */
class ScoreEntity extends ContentEntityBase implements ScoreEntityInterface {

  use EntityChangedTrait;
  use EntityOwnerTrait;

  /**
   * {@inheritdoc}
   */
  public function preSave(EntityStorageInterface $storage) {
    parent::preSave($storage);
    if (!$this->getOwnerId()) {
      // If no owner has been set explicitly, make the anonymous user the owner.
      $this->setOwnerId(0);
    }
  }

  /**
   * {@inheritdoc}
   */
  public static function baseFieldDefinitions(EntityTypeInterface $entity_type) {

    $fields = parent::baseFieldDefinitions($entity_type);

    // $fields['roll_no'] = BaseFieldDefinition::create('string')
    //   ->setLabel(t('Roll No.'))
    //   ->setRequired(TRUE)
    //   ->setSetting('max_length', 4)
    //   ->setDisplayOptions('form', [
    //     'type' => 'string_textfield',
    //     'weight' => -5,
    //   ])
    //   ->setDisplayConfigurable('form', TRUE)
    //   ->setDisplayOptions('view', [
    //     'label' => 'hidden',
    //     'type' => 'string',
    //     'weight' => -5,
    //   ])
    //   ->setDisplayConfigurable('view', TRUE);
    $fields = parent::baseFieldDefinitions($entity_type);
    $fields['roll_no'] = BaseFieldDefinition::create('entity_reference')
    ->setLabel(t('Roll no.'))
     ->setSetting('target_type', 'student_entity')
    ->setSetting('handler', 'default')
    ->setTargetEntityTypeId('student_entity')
    // ->setDefaultValueCallback(static::class . '::getDefaultEntityOwner')
    ->setDisplayOptions('form', [
      // 'type' => 'entity_reference_autocomplete',
      'settings' => [
        // 'match_operator' => 'CONTAINS',
        'size' => 60,
        'placeholder' => '',
      ],
      'weight' => 15,
    ])
    // ->setDisplayConfigurable('form', TRUE)
    // ->setDisplayOptions('view', [
    //   'label' => 'above',
    //   'type' => 'author',
    //   'weight' => 15,
    // ])
     ->setDisplayConfigurable('view', TRUE);
      $fields['subject'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Subject'))
      ->setRequired(TRUE)
      ->setSetting('max_length', 255)
      ->setDisplayOptions('form', [
        'type' => 'string_textfield',
        'weight' => -4,
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayOptions('view', [
        'label' => 'above',
        'type' => 'string',
        'weight' => -4,
      ])
      ->setDisplayConfigurable('view', TRUE);

      $fields['score'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Score'))
      ->setRequired(TRUE)
      ->setSetting('max_length', 25)
      ->setDisplayOptions('form', [
        'type' => 'string_textfield',
        'weight' => -3,
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayOptions('view', [
        'label' => 'above',
        'type' => 'string',
        'weight' => -3,
      ])
      ->setDisplayConfigurable('view', TRUE);

      
    // $fields['created'] = BaseFieldDefinition::create('created')
    //   ->setLabel(t('Authored on'))
    //   ->setDescription(t('The time that the score entity was created.'))
    //   ->setDisplayOptions('view', [
    //     'label' => 'above',
    //     'type' => 'timestamp',
    //     'weight' => 20,
    //   ])
    //   ->setDisplayConfigurable('form', TRUE)
    //   ->setDisplayOptions('form', [
    //     'type' => 'datetime_timestamp',
    //     'weight' => 20,
    //   ])
    //   ->setDisplayConfigurable('view', TRUE);

    // $fields['changed'] = BaseFieldDefinition::create('changed')
    //   ->setLabel(t('Changed'))
    //   ->setDescription(t('The time that the score entity was last edited.'));

    return $fields;
  }

}
