<?php

namespace Drupal\student\Entity;

use Drupal\Core\Entity\ContentEntityBase;
use Drupal\Core\Entity\EntityChangedTrait;
use Drupal\Core\Entity\EntityStorageInterface;
use Drupal\Core\Entity\EntityTypeInterface;
use Drupal\Core\Field\BaseFieldDefinition;
use Drupal\student\StudentEntityInterface;
use Drupal\user\EntityOwnerTrait;

/**
 * Defines the student entity entity class.
 *
 * @ContentEntityType(
 *   id = "student_entity",
 *   label = @Translation("student entity"),
 *   label_collection = @Translation("student entities"),
 *   label_singular = @Translation("student entity"),
 *   label_plural = @Translation("student entities"),
 *   label_count = @PluralTranslation(
 *     singular = "@count student entities",
 *     plural = "@count student entities",
 *   ),
 *   handlers = {
 *     "list_builder" = "Drupal\student\StudentEntityListBuilder",
 *     "views_data" = "Drupal\views\EntityViewsData",
 *     "access" = "Drupal\student\StudentEntityAccessControlHandler",
 *     "form" = {
 *       "add" = "Drupal\student\Form\StudentEntityForm",
 *       "edit" = "Drupal\student\Form\StudentEntityForm",
 *       "delete" = "Drupal\Core\Entity\ContentEntityDeleteForm",
 *     },
 *     "route_provider" = {
 *       "html" = "Drupal\Core\Entity\Routing\AdminHtmlRouteProvider",
 *     }
 *   },
 *   base_table = "student_entity",
 *   admin_permission = "administer student entity",
 *   entity_keys = {
 *     "id" = "id",
 *     "label" = "label",
 *     "uuid" = "uuid",
 *     "owner" = "uid",
 *   },
 *   links = {
 *     "collection" = "/admin/content/student-entity",
 *     "add-form" = "/student-entity/add",
 *     "canonical" = "/student-entity/{student_entity}",
 *     "edit-form" = "/student-entity/{student_entity}/edit",
 *     "delete-form" = "/student-entity/{student_entity}/delete",
 *   },
 *   field_ui_base_route = "entity.student_entity.settings",
 * )
 */
class StudentEntity extends ContentEntityBase implements StudentEntityInterface {

  use EntityChangedTrait;
  use EntityOwnerTrait;

  /**
   * {@inheritdoc}
   */
  public function preSave(EntityStorageInterface $storage) {
    parent::preSave($storage);
    if (!$this->getOwnerId()) {
      // If no owner has been set explicitly, make the anonymous user the owner.
      $this->setOwnerId(0);
    }
  }

  /**
   * {@inheritdoc}
   */
  public static function baseFieldDefinitions(EntityTypeInterface $entity_type) {

    $fields = parent::baseFieldDefinitions($entity_type);

    $fields['roll_no'] = BaseFieldDefinition::create('entity_reference')
      ->setLabel(t('Roll no'))
      // ->setSetting('target_type', 'user')
      // ->setDefaultValueCallback(static::class . '::getDefaultEntityOwner')
      ->setDisplayOptions('form', [
        // 'type' => 'entity_reference_autocomplete',
        'settings' => [
          // 'match_operator' => 'CONTAINS',
          'size' => 60,
          'placeholder' => '',
        ],
        'weight' => 15,
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayOptions('view', [
        // 'label' => 'above',
        // 'type' => 'author',
        // 'weight' => 15,
      ])
      ->setDisplayConfigurable('view', TRUE);
    $fields['name'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Name'))
      ->setRequired(TRUE)
      ->setSetting('max_length', 255)
      ->setDisplayOptions('form', [
        'type' => 'string_textfield',
        'weight' => -5,
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayOptions('view', [
        'label' => 'hidden',
        'type' => 'string',
        'weight' => -5,
      ])
      ->setDisplayConfigurable('view', TRUE);
      

      

      $fields['class'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Class'))
      ->setRequired(TRUE)
      ->setSetting('max_length', 4)
      ->setDisplayOptions('form', [
        'type' => 'string_textfield',
        'weight' => -2,
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayOptions('view', [
        'label' => 'hidden',
        'type' => 'string',
        'weight' => -2,
      ])
      ->setDisplayConfigurable('view', TRUE);

      $fields['contact_no'] = BaseFieldDefinition::create('string')
      ->setLabel(t('Contact No.'))
      ->setRequired(TRUE)
      ->setSetting('max_length', 10)
      ->setDisplayOptions('form', [
        'type' => 'string_textfield',
        'weight' => -3,
      ])
      ->setDisplayConfigurable('form', TRUE)
      ->setDisplayOptions('view', [
        'label' => 'hidden',
        'type' => 'string',
        'weight' => -3,
      ])
      ->setDisplayConfigurable('view', TRUE);
    // $fields['status'] = BaseFieldDefinition::create('boolean')
    //   ->setLabel(t('Status'))
    //   ->setDefaultValue(TRUE)
    //   ->setSetting('on_label', 'Enabled')
    //   ->setDisplayOptions('form', [
    //     'type' => 'boolean_checkbox',
    //     'settings' => [
    //       'display_label' => FALSE,
    //     ],
    //     'weight' => 0,
    //   ])
    //   ->setDisplayConfigurable('form', TRUE)
    //   ->setDisplayOptions('view', [
    //     'type' => 'boolean',
    //     'label' => 'above',
    //     'weight' => 0,
    //     'settings' => [
    //       'format' => 'enabled-disabled',
    //     ],
    //   ])
    //   ->setDisplayConfigurable('view', TRUE);

    // $fields['description'] = BaseFieldDefinition::create('text_long')
    //   ->setLabel(t('Description'))
    //   ->setDisplayOptions('form', [
    //     'type' => 'text_textarea',
    //     'weight' => 10,
    //   ])
    //   ->setDisplayConfigurable('form', TRUE)
    //   ->setDisplayOptions('view', [
    //     'type' => 'text_default',
    //     'label' => 'above',
    //     'weight' => 10,
    //   ])
    //   ->setDisplayConfigurable('view', TRUE);

    

    // $fields['created'] = BaseFieldDefinition::create('created')
    //   ->setLabel(t('Authored on'))
    //   ->setDescription(t('The time that the student entity was created.'))
    //   ->setDisplayOptions('view', [
    //     'label' => 'above',
    //     'type' => 'timestamp',
    //     'weight' => 20,
    //   ])
    //   ->setDisplayConfigurable('form', TRUE)
    //   ->setDisplayOptions('form', [
    //     'type' => 'datetime_timestamp',
    //     'weight' => 20,
    //   ])
    //   ->setDisplayConfigurable('view', TRUE);

    // $fields['changed'] = BaseFieldDefinition::create('changed')
    //   ->setLabel(t('Changed'))
    //   ->setDescription(t('The time that the student entity was last edited.'));

    return $fields;
  }

}
