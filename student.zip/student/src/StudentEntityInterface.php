<?php

namespace Drupal\student;

use Drupal\Core\Entity\ContentEntityInterface;
use Drupal\Core\Entity\EntityChangedInterface;
use Drupal\user\EntityOwnerInterface;

/**
 * Provides an interface defining a student entity entity type.
 */
interface StudentEntityInterface extends ContentEntityInterface, EntityOwnerInterface, EntityChangedInterface {

}
